=


Cau 2:
- Tính đóng gói là việc đóng gói dữ liệu (thuộc tính) và các phương thức (hành vi) vào trong một lớp (class), và hạn chế quyền truy cập trực tiếp vào các dữ liệu đó từ bên ngoài lớp. Thay vào đó, lớp sẽ cung cấp các phương thức getter và setter để truy cập và thay đổi giá trị của các thuộc tính này.

class Person {
    private String name;  // Thuộc tính private, không thể truy cập trực tiếp từ bên ngoài
    private int age;
    
    // Phương thức getter
    public String getName() {
        return name;
    }
    
    // Phương thức setter
    public void setName(String name) {
        this.name = name;
    }
    
    // Phương thức getter và setter cho age
    public int getAge() {
        return age;
    }
    
    public void setAge(int age) {
        if (age > 0) {  // Kiểm tra tính hợp lệ của dữ liệu
            this.age = age;
        }
    }
}

Tính kế thừa cho phép một lớp (lớp con) kế thừa các thuộc tính và phương thức từ một lớp khác (lớp cha). Điều này giúp tái sử dụng mã và tạo ra một cấu trúc phân cấp giữa các lớp.

// Lớp cha
class Animal {
    public void eat() {
        System.out.println("Animal is eating");
    }
}

// Lớp con kế thừa lớp Animal
class Dog extends Animal {
    // Lớp con có thể kế thừa phương thức eat() của lớp cha

    // Lớp con có thể thêm phương thức mới
    public void bark() {
        System.out.println("Dog is barking");
    }
}

public class Main {
    public static void main(String[] args) {
        Dog dog = new Dog();
        dog.eat();  // Kế thừa từ Animal
        dog.bark(); // Phương thức riêng của Dog
    }
}


Tính trừu tượng cho phép ẩn đi chi tiết triển khai của một đối tượng và chỉ cung cấp các thông tin cần thiết hoặc các phương thức cần thiết cho người dùng. Trong Java, tính trừu tượng có thể được thực hiện qua lớp trừu tượng (abstract class) hoặc giao diện (interface).
// Lớp trừu tượng
abstract class Animal {
    abstract void sound();  // Phương thức trừu tượng, lớp con phải cài đặt
    
    public void sleep() {
        System.out.println("Animal is sleeping");
    }
}

// Lớp con kế thừa và triển khai phương thức abstract
class Dog extends Animal {
    public void sound() {
        System.out.println("Dog barks");
    }
}

public class Main {
    public static void main(String[] args) {
        Dog dog = new Dog();
        dog.sound();  // Dog barks
        dog.sleep();  // Animal is sleeping
    }
}


Tính đa hình cho phép một đối tượng có thể xuất hiện dưới nhiều hình thức khác nhau. Đa hình có thể đạt được thông qua nhiều phương thức (method overloading) hoặc ghi đè phương thức (method overriding).
class Printer {
    // Phương thức in với một tham số
    public void print(String message) {
        System.out.println(message);
    }

    // Phương thức in với hai tham số
    public void print(String message, int times) {
        for (int i = 0; i < times; i++) {
            System.out.println(message);
        }
    }
}

public class Main {
    public static void main(String[] args) {
        Printer printer = new Printer();
        printer.print("Hello World!"); // Gọi phương thức in với 1 tham số
        printer.print("Hello World!", 3); // Gọi phương thức in với 2 tham số
    }
}



///////////////
abstract class MayTinh {
    private String maSo;
    private String thuongHieu;
    private double giaMua;
    private String CPU;

    public MayTinh(String maSo, String thuongHieu, double giaMua, String CPU) {
        this.maSo = maSo;
        this.thuongHieu = thuongHieu;
        this.giaMua = giaMua;
        this.CPU = CPU;
    }

    public String getMaSo() {
        return maSo;
    }

    public String getThuongHieu() {
        return thuongHieu;
    }

    public double getGiaMua() {
        return giaMua;
    }

    public String getCPU() {
        return CPU;
    }

    // Phương thức trừu tượng tính giá bán
    public abstract double tinhGiaBan();

    // Phương thức trừu tượng tính tiền lời
    public abstract double tinhTienLoi();
}

//
class Laptop extends MayTinh {
    public Laptop(String maSo, String thuongHieu, double giaMua, String CPU) {
        super(maSo, thuongHieu, giaMua, CPU);
    }

    @Override
    public double tinhGiaBan() {
        return getGiaMua() * 1.35; // Giá bán = 135% giá mua
    }

    @Override
    public double tinhTienLoi() {
        return tinhGiaBan() - getGiaMua(); // Tiền lời = Giá bán - Giá mua
    }
}


class MayBan extends MayTinh {
    private double trongLuong; // Đơn vị kg

    public MayBan(String maSo, String thuongHieu, double giaMua, String CPU, double trongLuong) {
        super(maSo, thuongHieu, giaMua, CPU);
        this.trongLuong = trongLuong;
    }

    @Override
    public double tinhGiaBan() {
        double phiGiaoHang = 3 * trongLuong; // Phí giao hàng = 3$ * trọng lượng (kg)
        return getGiaMua() * 1.2 + phiGiaoHang; // Giá bán = 120% giá mua + phí giao hàng
    }

    @Override
    public double tinhTienLoi() {
        return tinhGiaBan() - getGiaMua(); // Tiền lời = Giá bán - Giá mua
    }

    public double getTrongLuong() {
        return trongLuong;
    }
}

import java.util.ArrayList;

class UngDung {
    private ArrayList<MayTinh> danhSachMayTinh;

    public UngDung() {
        danhSachMayTinh = new ArrayList<>();
    }

    // Thêm thiết bị vào danh sách
    public void themMayTinh(MayTinh mayTinh) {
        danhSachMayTinh.add(mayTinh);
    }

    // Tính tổng tiền lời khi bán hết các thiết bị
    public double tinhTongTienLoi() {
        double tongTienLoi = 0;
        for (MayTinh mayTinh : danhSachMayTinh) {
            tongTienLoi += mayTinh.tinhTienLoi();
        }
        return tongTienLoi;
    }

    // In danh sách thiết bị
    public void inDanhSachMayTinh() {
        for (MayTinh mayTinh : danhSachMayTinh) {
            System.out.println("Mã số: " + mayTinh.getMaSo() + ", Thương hiệu: " + mayTinh.getThuongHieu()
                    + ", CPU: " + mayTinh.getCPU() + ", Giá mua: " + mayTinh.getGiaMua());
        }
    }
}


public class Main {
    public static void main(String[] args) {
        // Tạo ứng dụng
        UngDung ungDung = new UngDung();

        // Tạo các đối tượng Laptop
        Laptop laptop1 = new Laptop("L01", "Dell", 500, "Intel i5");
        Laptop laptop2 = new Laptop("L02", "HP", 600, "Intel i7");
        Laptop laptop3 = new Laptop("L03", "Asus", 450, "Intel i3");

        // Tạo các đối tượng MayBan
        MayBan mayBan1 = new MayBan("B01", "Acer", 300, "AMD Ryzen 5", 5);
        MayBan mayBan2 = new MayBan("B02", "Lenovo", 400, "Intel i5", 6);

        // Thêm vào ứng dụng
        ungDung.themMayTinh(laptop1);
        ungDung.themMayTinh(laptop2);
        ungDung.themMayTinh(laptop3);
        ungDung.themMayTinh(mayBan1);
        ungDung.themMayTinh(mayBan2);

        // In danh sách các thiết bị
        ungDung.inDanhSachMayTinh();

        // Tính và in tổng tiền lời
        double tongTienLoi = ungDung.tinhTongTienLoi();
        System.out.println("Tổng tiền lời khi bán hết thiết bị: " + tongTienLoi + " USD");
    }
}



Cau 3: 

Câu 1:
git clone repos xuly1
git clone repos xuly2

Câu 2:
cd xuly1
git status
git add .
git commit -m "Cau2"
git push
cd ../xuly2
git pull

Câu 3:
cd ../xuly1
git status
git add Shape.java
git commit -m "xuly1 Shape.java"
git push
cd ../xuly2
git status
git add Shape.java
git commit -m "xuly2 Shape.java"
git push

(Xử lí conflict)
git pull
- Sửa file Shape.java trong xuly2
git add .
git commit -m "conflict solve"
git push

cd ../xuly1
git pull

Câu 4:
git tag v2.1.1
git tag
git push origin v2.1.1

Câu 5:
git add .
git commit -m "change name Draw.java"
git push

cd ../xuly2
git pull

Câu 6:
cd ../xuly1

git tag
git checkout -b v2.1.1_bugfix v2.1.1
git merge

Câu 7:
git rm --cached readme.txt
git commit -m "Remove example.txt from tracking"
git push -u origin v2.1.1_bugfix
git status

Câu 8:
git tag v2.1.2
git push origin v2.1.2 v2.1.1_bugfix
git add .
git stash ( git stash apply)
git checkout master
git merge v2.1.1_bugfix

Câu 9:
git tag
git branch


1.	cd repos
	git remote add origin "email" (kết nối tk git) --- hoặc git config --global user.email "nhập email"
   	git init 
	git add .
	git commit -m "init"
	git config receive.denyCurrentBranch updateInstead
	git remote -v
	git remote add origin C:/Users/PC/Downloads/Cau3/repos (thay bằng đường dẫn bên a)
	git remote -v (ra 2 origin fetch vs push)
	git push origin master
	cd ../ (trả về folder Cau3)
	git clone repos we1
	git clone repos we2

2.	cd we1
	git init (test)
	git status 
	git add .
	git commit -m "chinh sua we1"
	git push origin master (hoặc main)
	>>>> làm tương tự với we2 <<<<<
	---nếu có xung đột: mở lại file code trong we2 kiếm xung đột (phần HEAD >>> main)
	git pull origin master 
git config pull.rebase false    
	git add .
	git commit -m "conflict"
	git push origin master (main)

3.	cd we1
	git add .
	git commit -m "update"
	git push origin master
	git pull

4.	cd we2
	git mv Main.java App.java
	git add App.java
	git commit -m "rename"
	git push origin master

5.	cd we1
	git branch
	git branch new_branch
	git checkout new_branch
	git branch

6.	cd we1
	touch Service.java
	git add Service.java
	git commit -m "new branch file"
	git push origin new_branch

7.	cd we1
	git diff main..new_branch

8.	cd we1
	git checkout main
	git pull origin main
	git merge new_branch

9.	cd we1
	git log --oneline	
	git log > history_we1.txt

	cd we2
	git log --oneline	
	git log > history_we1.txt

	







Cau 4: 

+-----------------+     +--------------------+     +-----------------+
|  Khách hàng    |     |    Đơn hàng        |     | Nhân viên giao  |
+-----------------+     +--------------------+     +-----------------+
| Mã KH           |<--- | Mã đơn hàng       | -->| Mã NV giao      |
| Tên KH          |     | Ngày đặt          |     | Tên NV giao     |
| Địa chỉ         |     | Tình trạng        |     | Số điện thoại   |
| Số điện thoại   |     | Mã khách hàng     |     +-----------------+
| Email           |     | Mã NV giao        |
+-----------------+     | Tổng tiền         |    
                        +--------------------+
                               |
                               |
                               v
                        +--------------------+ 
                        |  Chi tiết đơn hàng |
                        +--------------------+
                        | Mã đơn hàng        |
                        | Mã sản phẩm        |
                        | Số lượng           |
                        | Đơn giá            |
                        +--------------------+
                               |
                               v
                        +--------------------+
                        |     Sản phẩm       |
                        +--------------------+
                        | Mã sản phẩm        |
                        | Tên sản phẩm       |
                        | Giá                |
                        | Mô tả              |
                        | Số lượng tồn kho   |
                        +--------------------+




-- Tạo bảng Khách hàng
CREATE TABLE KhachHang (
    MaKH INT PRIMARY KEY AUTO_INCREMENT,
    TenKH VARCHAR(100),
    DiaChi VARCHAR(255),
    SoDienThoai VARCHAR(20),
    Email VARCHAR(100)
);

-- Tạo bảng Sản phẩm
CREATE TABLE SanPham (
    MaSP INT PRIMARY KEY AUTO_INCREMENT,
    TenSP VARCHAR(100),
    Gia DECIMAL(10, 2),
    MoTa TEXT,
    SoLuongTon INT
);

-- Tạo bảng Nhân viên giao hàng
CREATE TABLE NhanVienGiaoHang (
    MaNV INT PRIMARY KEY AUTO_INCREMENT,
    TenNV VARCHAR(100),
    SoDienThoai VARCHAR(20)
);

-- Tạo bảng Đơn hàng
CREATE TABLE DonHang (
    MaDH INT PRIMARY KEY AUTO_INCREMENT,
    NgayDat DATETIME,
    TinhTrang VARCHAR(50),
    MaKH INT,
    MaNVGiao INT,
    TongTien DECIMAL(10, 2),
    FOREIGN KEY (MaKH) REFERENCES KhachHang(MaKH),
    FOREIGN KEY (MaNVGiao) REFERENCES NhanVienGiaoHang(MaNV)
);

-- Tạo bảng Chi tiết đơn hàng
CREATE TABLE ChiTietDonHang (
    MaDH INT,
    MaSP INT,
    SoLuong INT,
    DonGia DECIMAL(10, 2),
    PRIMARY KEY (MaDH, MaSP),
    FOREIGN KEY (MaDH) REFERENCES DonHang(MaDH),
    FOREIGN KEY (MaSP) REFERENCES SanPham(MaSP)
);

-- Tạo bảng Thanh toán
CREATE TABLE ThanhToan (
    MaTT INT PRIMARY KEY AUTO_INCREMENT,
    MaDH INT,
    NgayTT DATETIME,
    PhuongThucThanhToan VARCHAR(50),
    TinhTrangThanhToan VARCHAR(50),
    FOREIGN KEY (MaDH) REFERENCES DonHang(MaDH)
);

-- Tạo bảng Nhà cung cấp
CREATE TABLE NhaCungCap (
    MaNCC INT PRIMARY KEY AUTO_INCREMENT,
    TenNCC VARCHAR(100),
    DiaChi VARCHAR(255),
    SoDienThoai VARCHAR(20)
);

-- Tạo bảng Mối quan hệ giữa sản phẩm và nhà cung cấp
CREATE TABLE SanPhamNhaCungCap (
    MaSP INT,
    MaNCC INT,
    PRIMARY KEY (MaSP, MaNCC),
    FOREIGN KEY (MaSP) REFERENCES SanPham(MaSP),
    FOREIGN KEY (MaNCC) REFERENCES NhaCungCap(MaNCC)
);

